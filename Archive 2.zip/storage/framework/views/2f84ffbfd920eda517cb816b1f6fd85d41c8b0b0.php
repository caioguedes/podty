<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    search for podcasts:
                    <input type="text">
                    <hr>

                    <div class="panel-heading">Latests Feeds</div>
                    <ul>
                        <?php foreach($data['feeds'] as $feed): ?>
                            <img src="<?php echo e($feed['thumbnail_30']); ?>">
                            <span>
                                <a href="/podcast/<?php echo e($feed['name']); ?>" target="_blank">
                                <?php echo e($feed['name']); ?>

                                </a>
                            </span>
                            <b>(<?php echo e($feed['total_episodes']); ?>)</b>
                            <br>
                            Last Episode: <?php echo e((new DateTime($feed['last_episode_at']))->format('d/m/Y H:i')); ?>

                            <hr>
                        <?php endforeach; ?>
                    </ul>

                    <div class="panel-heading">Latests Episodes</div>
                    <?php foreach($data['episodes'] as $episode): ?>
                        <img src="<?php echo e($episode['thumbnail_30']); ?>">
                        <a href="<?php echo e($episode['link']); ?>" target="_blank">
                            <b><?php echo e($episode['title']); ?></b>
                        </a> -
                        <?php echo e((new DateTime($episode['published_date']))->format('d/m/Y H:i')); ?> <br>
                        <audio controls>
                            <source src=<?php echo e($episode['media_url']); ?> type=<?php echo e($episode['media_type']); ?>>
                        </audio>
                        <hr>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>