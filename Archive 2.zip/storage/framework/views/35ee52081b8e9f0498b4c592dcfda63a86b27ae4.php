<?php $__env->startSection('title', 'BrnPod'); ?>

<?php $__env->startSection('head'); ?>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link href="/css/home.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">

        <div class="col-lg-2 col-md-2 hidden-sm hidden-xs">
            <div class="panel panel-default">
                <div class="panel-body latests-episodes">
                    <ul class="latests-episodes-list">
                        <?php $i=0; ?>
                        <?php $__empty_1 = true; foreach($data['episodes'] as $episode): $__empty_1 = false; ?>
                            <li>
                                <a href="/podcast/<?php echo e($episode['podcast_id']); ?>" class="text-center">
                                    <small class="text-center episode-title">
                                        <?php echo e($episode['title']); ?>

                                    </small>
                                    <img src="<?php echo e($episode['thumbnail_30']); ?>" class="img-circle" >
                                </a>
                            </li>
                            <?php $i++; ?>
                            <?php if($i < count($data['episodes'])): ?> <hr> <?php endif; ?>
                        <?php endforeach; if ($__empty_1): ?>
                            <div class="col-lg-12 col-md-6 col-sm-12">
                                <p>service not available.</p>
                            </div>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>


        <div class="col-lg-8  col-md-8 col-sm-9 col-xs-12">
            <div class="panel panel-default find">
                <div class="panel-body find-podcasts">
                    <input type="text" class="find-podcast-search form-control">
                    <div class="find-podcast-results">
                        <ul></ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-2 col-md-2 col-sm-3 hidden-xs">
            <div class="panel panel-default">
                <div class="panel-body latests-podcasts">
                    <ul class="latests-podcasts-list">
                    <?php $__empty_1 = true; foreach($data['podcasts'] as $podcast): $__empty_1 = false; ?>
                        <li>
                            <a href="/podcast/<?php echo e($podcast['id']); ?>">
                                <span class="podcast-title">
                                    <?php echo e($podcast['name']); ?>

                                </span><br>
                                <span class="podcast-date">
                                    <?php echo e($podcast['last_episode_at']); ?>

                                </span>
                                <span class="podcast-img">
                                    <img src="<?php echo e($podcast['thumbnail_60']); ?>" class="img-circle">
                                </span>
                            </a>
                        </li>
                    <?php endforeach; if ($__empty_1): ?>
                            <div class="col-lg-12 col-md-6 col-sm-12">
                                <p>service not available.</p>
                            </div>
                    <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="/js/home.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>