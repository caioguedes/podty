<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4>
                        Latest Episodes of <br><br>
                            <img src="<?php echo e($data['feed']['thumbnail_60']); ?>" alt="">
                        <b><?php echo e(explode(' - ', $data['feed']['name'])[0]); ?></b>
                        (<?php echo e($data['feed']['total_episodes']); ?>)
                    </h4>
                </div>
                <div class="panel-body">
                    <?php foreach($data['episodes'] as $episode): ?>
                        <div class="row text-left">
                            <b><?php echo e((new DateTime($episode['published_date']))->format('d/m/Y H:i')); ?></b>
                            <br>
                            <a href="<?php echo e($episode['link']); ?>" target="_blank">
                                <b><?php echo e($episode['title']); ?></b>
                            </a>
                            <br>
                            <br><br>
                            <audio controls>
                                <source src=<?php echo e($episode['media_url']); ?> type=<?php echo e($episode['media_type']); ?>>
                            </audio>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                </div>
                <a href="#">next</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>